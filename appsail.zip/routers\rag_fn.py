import logging
import uuid
from typing import Optional, List
from fastapi import APIRouter, Request, HTTPException, status, UploadFile, File
from pydantic import BaseModel

from appsail.services.rag_agent import rag_agent
from appsail.services.document_processor import document_processor
from appsail.postgres_repo import pg_repo
from rate_limit import limiter

logger = logging.getLogger("appsail.rag_fn")
router = APIRouter(prefix="/server/rag")

class QueryRequest(BaseModel):
    query: str

@router.post("/query")
@limiter.limit("20/minute")
async def rag_query(req: QueryRequest, request: Request):
    """
    Main endpoint for the AI Investigation Assistant.
    Routes the natural language query via the Intelligent AI Router.
    """
    if not req.query:
        raise HTTPException(status_code=400, detail="Query string is required.")
        
    try:
        response = await rag_agent.execute_query(req.query)
        return response
    except Exception as e:
        logger.error(f"RAG query failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/upload")
async def upload_document(request: Request, file: UploadFile = File(...)):
    """
    Uploads a document (PDF, Text), processes it into chunks, generates embeddings, 
    and stores them in pgvector.
    """
    try:
        content = await file.read()
        text_content = content.decode('utf-8', errors='ignore')
        
        doc_id = f"DOC-{uuid.uuid4().hex[:8].upper()}"
        
        # In a real scenario, insert the Document into the database here
        insert_doc_query = """
            INSERT INTO Documents (document_id, title, source_type, content, uploaded_by)
            VALUES ($1, $2, $3, $4, $5)
        """
        # Note: 'admin' would be replaced with actual user from request context
        await pg_repo.execute(insert_doc_query, doc_id, file.filename, "Uploaded_File", text_content, "admin")

        chunks = document_processor.process_text(text_content, doc_id)
        
        # Insert chunks and embeddings
        insert_chunk_query = """
            INSERT INTO DocumentChunks (document_id, chunk_index, chunk_text, embedding)
            VALUES ($1, $2, $3, $4::vector)
        """
        
        for chunk in chunks:
            embedding_str = "[" + ",".join(str(x) for x in chunk["embedding"]) + "]"
            await pg_repo.execute(insert_chunk_query, doc_id, chunk["chunk_index"], chunk["chunk_text"], embedding_str)
            
        return {"status": "success", "document_id": doc_id, "chunks_processed": len(chunks)}
        
    except Exception as e:
        logger.error(f"Document upload failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/search")
async def search_documents(req: QueryRequest):
    """
    Direct semantic search for documents (bypass AI router).
    """
    try:
        response = await rag_agent._vector_agent(req.query)
        return response
    except Exception as e:
        logger.error(f"Search failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/explain")
async def explain_decision(req: QueryRequest):
    """
    Explainable AI endpoint to elaborate on why a specific conclusion was drawn.
    """
    system_prompt = "You are an explainable AI. Explain in detail the reasoning behind the following query/statement, citing evidence from the knowledge base."
    try:
        explanation = rag_agent.call_ai(system_prompt, req.query)
        return {"explanation": explanation}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
